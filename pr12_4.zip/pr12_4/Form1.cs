﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr12_4
{
    public partial class Form1 : Form
    {
        Sportsmen []mass = new Sportsmen[10];
        public Form1()
        {
            InitializeComponent();

        }
        int i = 0;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "" && textBox8.Text != "")
                {

                    mass[i].Name=(textBox1.Text);
                    mass[i].fname = textBox2.Text;
                    mass[i].lname = textBox3.Text;
                    mass[i].SetPol(textBox4.Text);
                    mass[i].SetYears(Convert.ToDouble(textBox5.Text));
                    mass[i].SetRost(Convert.ToDouble(textBox6.Text));
                    mass[i].SetVes(Convert.ToDouble(textBox7.Text));
                    mass[i].vidsp = textBox8.Text;
                    double idvesBrok = mass[i].IdvesBrok();
                    double idvesKup = mass[i].IdvesKupper();
                    double rost = mass[i].GetRost();
                    double ves=mass[i].GetVes();
                    if (idvesBrok == 0)
                        MessageBox.Show("Возраст не может быть отрицательным или равен нулю");
                    else if (rost < 140)
                        MessageBox.Show("Рост не может быть меньше 140 см");
                    else if (ves < 30)
                        MessageBox.Show("Вес не может быть меньше 30 кг");
                    else if (idvesKup == 0)
                        MessageBox.Show("Такого пола нет");

                    else
                        MessageBox.Show(mass[i].GetInfo() + "\nИдеальный вес по формуле Брока: " + idvesBrok + "\nИдеальный вес по формуле Купера: " + idvesKup);
                }
                else
                    MessageBox.Show("Заполните все поля");
            }
            catch
            {
                MessageBox.Show("Неверный формат данных");
            }
        }
    }
}
